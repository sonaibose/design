/*---Slider Carousel Start---*/
var stlen = $('#slider .strip a').size();
var stx = 0;
var stpos = 0;
var stspeed = 500;
var stdelay = 5000;
var stpause = false;
var stto = null;
var stwidth = 1680;

function sliderTopRun() {
    if(!stpause) {
        stx = stpos * -stwidth;
        $('#slider .strip').animate({left: stx+'px'}, stspeed);
    }
    if(stto) clearTimeout(stto);
    stto = setTimeout(sliderTopNext, stdelay);
}
function sliderTopPrev() {
    if(!stpause) {
        stpos--;
        if(stpos < 0) stpos = stlen - 1;
    }
    sliderTopRun();
}
function sliderTopNext() {
    if(!stpause) {
        stpos++;
        if(stpos >= stlen) stpos = 0;
    }
    sliderTopRun();
}
$('#slider .strip').css('width', (stlen * stwidth)+'px');
$('#slider .next').click(sliderTopNext);
$('#slider .prev').click(sliderTopPrev);
$('#slider .strip').hover(
    function(e) { stpause = true; },
    function(e) { stpause = false; }
);
sliderTopRun();

/*---Slider Carousel End---*/


/*---Counter Increment Scroll Time---*/
var a = 0;
$(window).scroll(function() {
  var oTop = $('#counter').offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.counter-value').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },
        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
          }

        });
    });
    a = 1;
  }

});

/*---Counter Increment Scroll Time---*/

window.onscroll = function() {scrollFunction()};

function scrollFunction() 
{
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) 
  {
      $(".image-fix").addClass('image-fixed');
  }
  else 
  {
    $(".image-fix").removeClass('image-fixed');
  }
}

/*--Mobile Menu--*/
$(".menuicon").click(function()
{
  $(".custom-nav").slideToggle();
});
